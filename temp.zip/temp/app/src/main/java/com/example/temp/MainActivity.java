package com.example.temp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content view to the XML layout file
        setContentView(R.layout.activity_main); // This loads activity_main.xml

        // No additional functionality is needed for display purposes
    }
}
